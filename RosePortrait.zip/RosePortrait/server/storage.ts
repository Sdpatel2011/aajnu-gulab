import { images, type Image, type InsertImage } from "@shared/schema";

export interface IStorage {
  saveImage(image: InsertImage): Promise<Image>;
  getImage(id: number): Promise<Image | undefined>;
}

export class MemStorage implements IStorage {
  private images: Map<number, Image>;
  private currentId: number;

  constructor() {
    this.images = new Map();
    this.currentId = 1;
  }

  async saveImage(insertImage: InsertImage): Promise<Image> {
    const id = this.currentId++;
    const image: Image = { id, ...insertImage };
    this.images.set(id, image);
    return image;
  }

  async getImage(id: number): Promise<Image | undefined> {
    return this.images.get(id);
  }
}

export const storage = new MemStorage();
