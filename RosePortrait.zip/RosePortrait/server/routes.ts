import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertImageSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  app.post("/api/images", async (req, res) => {
    const result = insertImageSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    
    const image = await storage.saveImage(result.data);
    res.json(image);
  });

  app.get("/api/images/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const image = await storage.getImage(id);
    
    if (!image) {
      return res.status(404).json({ error: "Image not found" });
    }
    
    res.json(image);
  });

  return createServer(app);
}
