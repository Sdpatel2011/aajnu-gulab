import { pgTable, text, serial, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const images = pgTable("images", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  imageData: text("image_data").notNull(),
  settings: jsonb("settings").notNull().$type<{
    scale: number;
    y: number;
    overlayText: string;
    personName: string;
    background: string;
  }>(),
});

export const insertImageSchema = createInsertSchema(images).omit({ id: true });

export type InsertImage = z.infer<typeof insertImageSchema>;
export type Image = typeof images.$inferSelect;
