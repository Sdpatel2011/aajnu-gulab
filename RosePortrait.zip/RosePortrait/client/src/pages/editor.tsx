import { Card } from "@/components/ui/card";
import Canvas from "@/components/editor/canvas";
import Controls from "@/components/editor/controls";
import AdPlaceholder from "@/components/editor/ad-placeholder";
import { useState } from "react";

export default function Editor() {
  const [image, setImage] = useState<string | null>(null);
  const [scale, setScale] = useState(1);
  const [yPosition, setYPosition] = useState(0);
  const [overlayText] = useState("Today's rose");
  const [personName, setPersonName] = useState("");
  const [background, setBackground] = useState("#ffffff");

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <div className="max-w-6xl mx-auto grid grid-cols-12 gap-4">
        <div className="col-span-2">
          <AdPlaceholder className="h-full" />
        </div>
        
        <div className="col-span-8">
          <Card className="p-6">
            <h1 className="text-3xl font-bold text-center mb-6 bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
              Photo Editor
            </h1>
            
            <Canvas
              image={image}
              scale={scale}
              yPosition={yPosition}
              overlayText={overlayText}
              personName={personName}
              background={background}
            />
            
            <Controls
              onImageUpload={setImage}
              scale={scale}
              onScaleChange={setScale}
              yPosition={yPosition}
              onYPositionChange={setYPosition}
              personName={personName}
              onPersonNameChange={setPersonName}
              background={background}
              onBackgroundChange={setBackground}
            />
          </Card>
        </div>
        
        <div className="col-span-2">
          <AdPlaceholder className="h-full" />
        </div>
      </div>
    </div>
  );
}
