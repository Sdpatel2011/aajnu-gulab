import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { useState } from "react";

interface TextOverlayProps {
  personName: string;
  onPersonNameChange: (name: string) => void;
}

export default function TextOverlay({
  personName,
  onPersonNameChange,
}: TextOverlayProps) {
  const [textSize] = useState(32);
  const [textOpacity] = useState(100);

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-base font-medium">Text Overlay</Label>
        <div className="mt-2 p-3 bg-muted/50 rounded-lg">
          <p className="text-sm text-muted-foreground mb-1">Fixed Text:</p>
          <p className="font-semibold">આજનું ગુલાબ</p>
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div>
          <Label htmlFor="personName">Person Name</Label>
          <Input
            id="personName"
            value={personName}
            onChange={(e) => onPersonNameChange(e.target.value)}
            placeholder="Enter name"
            className="mt-1.5"
          />
        </div>

        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Text Size</Label>
            <span className="text-sm text-muted-foreground">{textSize}px</span>
          </div>
          <Slider
            value={[textSize]}
            min={16}
            max={48}
            step={1}
            disabled
            className="mt-1.5"
          />
        </div>

        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Text Opacity</Label>
            <span className="text-sm text-muted-foreground">{textOpacity}%</span>
          </div>
          <Slider
            value={[textOpacity]}
            min={0}
            max={100}
            step={1}
            disabled
            className="mt-1.5"
          />
        </div>

        <div className="p-3 bg-muted/50 rounded-lg">
          <p className="text-sm text-muted-foreground">
            Note: Text will be displayed with a white fill and black outline for
            maximum visibility across different backgrounds.
          </p>
        </div>
      </div>
    </div>
  );
}
