import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ImageIcon, Palette } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const backgroundImages = [
  { id: 'flowers', url: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&q=80&w=1000' },
  { id: 'gradient', url: 'https://images.unsplash.com/photo-1557682250-33bd709cbe85?auto=format&fit=crop&q=80&w=1000' },
  { id: 'abstract', url: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=1000' },
];

interface BackgroundPickerProps {
  value: string;
  onChange: (value: string) => void;
}

export default function BackgroundPicker({ value, onChange }: BackgroundPickerProps) {
  const isColor = value.startsWith('#');

  return (
    <div className="space-y-4">
      <div>
        <Label>Background Style</Label>
        <RadioGroup
          defaultValue={isColor ? 'color' : 'image'}
          className="grid grid-cols-2 gap-4 mt-2"
          onValueChange={(val) => {
            if (val === 'color') {
              onChange('#ffffff');
            } else {
              onChange(backgroundImages[0].url);
            }
          }}
        >
          <div>
            <RadioGroupItem
              value="color"
              id="color"
              className="peer sr-only"
            />
            <Label
              htmlFor="color"
              className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-background p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
            >
              <Palette className="mb-2 h-6 w-6" />
              <span className="text-sm font-medium">Solid Color</span>
            </Label>
          </div>
          <div>
            <RadioGroupItem
              value="image"
              id="image"
              className="peer sr-only"
            />
            <Label
              htmlFor="image"
              className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-background p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
            >
              <ImageIcon className="mb-2 h-6 w-6" />
              <span className="text-sm font-medium">Image</span>
            </Label>
          </div>
        </RadioGroup>
      </div>

      {isColor ? (
        <div className="space-y-2">
          <Label>Color</Label>
          <div className="flex gap-4">
            <Input
              type="color"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className="w-20 h-10"
            />
            <Input
              type="text"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="#FFFFFF"
              className="flex-1"
            />
          </div>
        </div>
      ) : (
        <div className="space-y-2">
          <Label>Background Image</Label>
          <div className="grid grid-cols-3 gap-4">
            {backgroundImages.map((bg) => (
              <div
                key={bg.id}
                className={`relative aspect-video cursor-pointer rounded-lg overflow-hidden border-2 ${
                  value === bg.url ? 'border-primary' : 'border-muted'
                }`}
                onClick={() => onChange(bg.url)}
              >
                <img
                  src={bg.url}
                  alt={bg.id}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}