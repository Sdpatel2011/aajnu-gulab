import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import BackgroundPicker from "./background-picker";
import { Download, Share2, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ControlsProps {
  onImageUpload: (image: string) => void;
  scale: number;
  onScaleChange: (scale: number) => void;
  yPosition: number;
  onYPositionChange: (y: number) => void;
  personName: string;
  onPersonNameChange: (name: string) => void;
  background: string;
  onBackgroundChange: (color: string) => void;
}

export default function Controls({
  onImageUpload,
  scale,
  onScaleChange,
  yPosition,
  onYPositionChange,
  personName,
  onPersonNameChange,
  background,
  onBackgroundChange
}: ControlsProps) {
  const { toast } = useToast();
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result;
      if (typeof result === "string") {
        onImageUpload(result);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <div>
        <Label>Upload Image</Label>
        <Input
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="mt-2"
        />
      </div>

      <div>
        <Label>Image Scale</Label>
        <Slider
          value={[scale]}
          onValueChange={([value]) => onScaleChange(value)}
          min={0.1}
          max={2}
          step={0.1}
          className="mt-2"
        />
      </div>

      <div>
        <Label>Vertical Position</Label>
        <Slider
          value={[yPosition]}
          onValueChange={([value]) => onYPositionChange(value)}
          min={-100}
          max={100}
          className="mt-2"
        />
      </div>

      <div>
        <Label>Person Name</Label>
        <Input
          value={personName}
          onChange={(e) => onPersonNameChange(e.target.value)}
          placeholder="Enter name"
          className="mt-2"
        />
      </div>

      <BackgroundPicker
        value={background}
        onChange={onBackgroundChange}
      />

      <div className="flex gap-4">
        <Button
          onClick={() => {
            toast({
              title: "Download started",
              description: "Your image will download shortly"
            });
          }}
        >
          <Download className="w-4 h-4 mr-2" />
          Download
        </Button>
        
        <Button variant="secondary">
          <Share2 className="w-4 h-4 mr-2" />
          Share
        </Button>
      </div>
    </div>
  );
}
