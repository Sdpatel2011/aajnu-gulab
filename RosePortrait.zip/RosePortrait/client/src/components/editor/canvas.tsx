import { useEffect, useRef } from "react";
import { drawCanvas } from "@/lib/canvas-utils";

interface CanvasProps {
  image: string | null;
  scale: number;
  yPosition: number;
  overlayText: string;
  personName: string;
  background: string;
}

export default function Canvas(props: CanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    drawCanvas(canvas, props);
  }, [props]);

  return (
    <div className="flex justify-center mb-6">
      <canvas
        ref={canvasRef}
        width={600}
        height={600}
        className="border border-border rounded-lg shadow-sm"
      />
    </div>
  );
}
