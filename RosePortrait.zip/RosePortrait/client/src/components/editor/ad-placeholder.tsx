import { cn } from "@/lib/utils";

interface AdPlaceholderProps {
  className?: string;
}

export default function AdPlaceholder({ className }: AdPlaceholderProps) {
  return (
    <div className={cn(
      "bg-muted/50 rounded-lg border border-dashed border-muted-foreground/50 flex items-center justify-center p-4",
      className
    )}>
      <p className="text-sm text-muted-foreground text-center">
        Ad Space
      </p>
    </div>
  );
}
