interface CanvasProps {
  image: string | null;
  scale: number;
  yPosition: number;
  overlayText: string;
  personName: string;
  background: string;
}

export function drawCanvas(
  canvas: HTMLCanvasElement,
  { image, scale, yPosition, overlayText, personName, background }: CanvasProps
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  // Clear canvas
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Draw background
  const drawBackground = () => {
    if (background.startsWith('#')) {
      ctx.fillStyle = background;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    } else {
      const bgImage = new Image();
      bgImage.onload = () => {
        // Scale the background to cover the canvas while maintaining aspect ratio
        const bgAspect = bgImage.width / bgImage.height;
        const canvasAspect = canvas.width / canvas.height;

        let drawWidth = canvas.width;
        let drawHeight = canvas.height;
        let x = 0;
        let y = 0;

        if (bgAspect > canvasAspect) {
          drawWidth = canvas.height * bgAspect;
          x = (canvas.width - drawWidth) / 2;
        } else {
          drawHeight = canvas.width / bgAspect;
          y = (canvas.height - drawHeight) / 2;
        }

        ctx.drawImage(bgImage, x, y, drawWidth, drawHeight);

        // Draw the main image on top after background is loaded
        drawMainImage();
      };
      bgImage.src = background;
    }
  };

  // Draw main image
  const drawMainImage = () => {
    if (image) {
      const img = new Image();
      img.onload = () => {
        const aspectRatio = img.width / img.height;
        const targetWidth = canvas.width * scale;
        const targetHeight = targetWidth / aspectRatio;

        const x = (canvas.width - targetWidth) / 2;
        const y = (canvas.height - targetHeight) / 2 + yPosition;

        ctx.drawImage(img, x, y, targetWidth, targetHeight);

        // Draw text overlays
        drawText();
      };
      img.src = image;
    } else {
      drawText();
    }
  };

  // Draw text overlays
  const drawText = () => {
    ctx.fillStyle = "white";
    ctx.strokeStyle = "black";
    ctx.lineWidth = 2;
    ctx.textAlign = "center";

    // Draw main text
    ctx.font = "bold 32px sans-serif";
    ctx.strokeText(overlayText, canvas.width / 2, 50);
    ctx.fillText(overlayText, canvas.width / 2, 50);

    // Draw person name if provided
    if (personName) {
      ctx.font = "24px sans-serif";
      ctx.strokeText(personName, canvas.width / 2, canvas.height - 30);
      ctx.fillText(personName, canvas.width / 2, canvas.height - 30);
    }
  };

  // Start the drawing process with background
  drawBackground();
}